package com.example.securingweb;

import org.springframework.beans.factory.annotation.Autowired;

public class JdbcUserDetailManager {
    //@Autowired
    // Database
    
    //UserExists
}